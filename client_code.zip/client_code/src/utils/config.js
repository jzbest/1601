const config = {
    get() {
        return {
            url : process.env.VUE_APP_BASE_API_URL + process.env.VUE_APP_BASE_API + '/',
            name: process.env.VUE_APP_BASE_API,
			menuList:[
				{
					name: '竞赛信息管理',
					icon: '',
					child:[

						{
							name:'竞赛信息',
                            url:'/index/jingsaixinxiList'

						},
					]
				},
				{
					name: '报名信息管理',
					icon: '',
					child:[

						{
							name:'报名信息',
                            url:'/index/baomingxinxiList'

						},
					]
				},
				{
					name: '新闻资讯管理',
					icon: '',
					child:[

						{
							name:'系统通知',
                            url:'/index/newsList'

						},
					]
				},
			]
        }
    },
    getProjectName(){
        return {
            projectName: `大学生竞赛管理系统`
        } 
    }
}
export default config

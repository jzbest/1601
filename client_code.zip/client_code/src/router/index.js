import { createRouter, createWebHashHistory } from 'vue-router'
import index from '../views'
import home from '../views/pages/home.vue'
import login from '../views/pages/login.vue'
import newsList from '@/views/pages/news/list'
import syslogList from '@/views/pages/syslog/list'
import syslogDetail from '@/views/pages/syslog/formModel'
import syslogAdd from '@/views/pages/syslog/formAdd'
import xueshengList from '@/views/pages/xuesheng/list'
import xueshengDetail from '@/views/pages/xuesheng/formModel'
import xueshengAdd from '@/views/pages/xuesheng/formAdd'
import xueshengRegister from '@/views/pages/xuesheng/register'
import xueshengCenter from '@/views/pages/xuesheng/center'
import jingsaixinxiList from '@/views/pages/jingsaixinxi/list'
import jingsaixinxiDetail from '@/views/pages/jingsaixinxi/formModel'
import jingsaixinxiAdd from '@/views/pages/jingsaixinxi/formAdd'
import storeupList from '@/views/pages/storeup/list'
import baomingxinxiList from '@/views/pages/baomingxinxi/list'
import baomingxinxiDetail from '@/views/pages/baomingxinxi/formModel'
import baomingxinxiAdd from '@/views/pages/baomingxinxi/formAdd'
import pingweiList from '@/views/pages/pingwei/list'
import pingweiDetail from '@/views/pages/pingwei/formModel'
import pingweiAdd from '@/views/pages/pingwei/formAdd'
import jiarutuanduiList from '@/views/pages/jiarutuandui/list'
import jiarutuanduiDetail from '@/views/pages/jiarutuandui/formModel'
import jiarutuanduiAdd from '@/views/pages/jiarutuandui/formAdd'
import dafenxinxiList from '@/views/pages/dafenxinxi/list'
import dafenxinxiDetail from '@/views/pages/dafenxinxi/formModel'
import dafenxinxiAdd from '@/views/pages/dafenxinxi/formAdd'
import jiangpinxinxiList from '@/views/pages/jiangpinxinxi/list'
import jiangpinxinxiDetail from '@/views/pages/jiangpinxinxi/formModel'
import jiangpinxinxiAdd from '@/views/pages/jiangpinxinxi/formAdd'

const routes = [{
		path: '/',
		redirect: '/index/home'
	},
	{
		path: '/index',
		component: index,
		children: [{
			path: 'home',
			component: home
		}
		, {
			path: 'newsList',
			component: newsList
		}
		, {
			path: 'syslogList',
			component: syslogList
		}, {
			path: 'syslogDetail',
			component: syslogDetail
		}, {
			path: 'syslogAdd',
			component: syslogAdd
		}
		, {
			path: 'xueshengList',
			component: xueshengList
		}, {
			path: 'xueshengDetail',
			component: xueshengDetail
		}, {
			path: 'xueshengAdd',
			component: xueshengAdd
		}
		, {
			path: 'xueshengCenter',
			component: xueshengCenter
		}
		, {
			path: 'jingsaixinxiList',
			component: jingsaixinxiList
		}, {
			path: 'jingsaixinxiDetail',
			component: jingsaixinxiDetail
		}, {
			path: 'jingsaixinxiAdd',
			component: jingsaixinxiAdd
		}
        , {
            path: 'storeupList',
            component: storeupList
        }
		, {
			path: 'baomingxinxiList',
			component: baomingxinxiList
		}, {
			path: 'baomingxinxiDetail',
			component: baomingxinxiDetail
		}, {
			path: 'baomingxinxiAdd',
			component: baomingxinxiAdd
		}
		, {
			path: 'pingweiList',
			component: pingweiList
		}, {
			path: 'pingweiDetail',
			component: pingweiDetail
		}, {
			path: 'pingweiAdd',
			component: pingweiAdd
		}
		, {
			path: 'jiarutuanduiList',
			component: jiarutuanduiList
		}, {
			path: 'jiarutuanduiDetail',
			component: jiarutuanduiDetail
		}, {
			path: 'jiarutuanduiAdd',
			component: jiarutuanduiAdd
		}
		, {
			path: 'dafenxinxiList',
			component: dafenxinxiList
		}, {
			path: 'dafenxinxiDetail',
			component: dafenxinxiDetail
		}, {
			path: 'dafenxinxiAdd',
			component: dafenxinxiAdd
		}
		, {
			path: 'jiangpinxinxiList',
			component: jiangpinxinxiList
		}, {
			path: 'jiangpinxinxiDetail',
			component: jiangpinxinxiDetail
		}, {
			path: 'jiangpinxinxiAdd',
			component: jiangpinxinxiAdd
		}
		]
	},
	{
		path: '/login',
		component: login
	}
	,{
		path: '/xueshengRegister',
		component: xueshengRegister
	}
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})

export default router

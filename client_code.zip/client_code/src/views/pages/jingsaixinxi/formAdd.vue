<template>
	<div class="edit_view" :style='{}'>
        <div class="breadcrumb-wrapper" style="width: 100%;">
            <div class="bread_view">
                <el-breadcrumb separator="/" class="breadcrumb">
                    <el-breadcrumb-item class="first_breadcrumb" :to="{ path: '/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item class="second_breadcrumb" v-for="(item,index) in breadList" :key="index">{{item.name}}</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </div>
		<el-form ref="formRef" :model="form" class="add_form" label-width="120px" :rules="rules">
			<el-row>
				<el-col :span="12">
					<el-form-item label="竞赛名称" prop="jingsaimingcheng">
						<el-input class="list_inp"
                                  v-model="form.jingsaimingcheng"
                                  placeholder="竞赛名称"
                                  type="text"
							      :readonly="!isAdd||disabledForm.jingsaimingcheng?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="竞赛图片" prop="jingsaitupian">
						<uploads
							:disabled="!isAdd||disabledForm.jingsaitupian?true:false"
							action="file/upload" 
							tip="请上传竞赛图片"
							style="width: 100%;text-align: left;"
							:fileUrls="form.jingsaitupian?form.jingsaitupian:''" 
							@change="jingsaitupianUploadSuccess">
						</uploads>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="竞赛时间" prop="jingsaishijian">
						<el-date-picker
							class="list_date"
							v-model="form.jingsaishijian"
							format="YYYY-MM-DD HH:mm:ss"
							value-format="YYYY-MM-DD HH:mm:ss"
							type="datetime"
							style="width:100%;"
							:readonly="!isAdd||disabledForm.jingsaishijian?true:false"
							placeholder="请选择竞赛时间" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="竞赛学科" prop="jingsaixueke">
						<el-input class="list_inp"
                                  v-model="form.jingsaixueke"
                                  placeholder="竞赛学科"
                                  type="text"
							      :readonly="!isAdd||disabledForm.jingsaixueke?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="竞赛地点" prop="jingsaididian">
						<el-input class="list_inp"
                                  v-model="form.jingsaididian"
                                  placeholder="竞赛地点"
                                  type="text"
							      :readonly="!isAdd||disabledForm.jingsaididian?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="最近点击时间" prop="reversetime">
						<el-date-picker
							class="list_date"
							v-model="form.reversetime"
							format="YYYY-MM-DD HH:mm:ss"
							value-format="YYYY-MM-DD HH:mm:ss"
							type="datetime"
							style="width:100%;"
							:readonly="!isAdd||disabledForm.reversetime?true:false"
							placeholder="请选择最近点击时间" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="报名要求" prop="baomingyaoqiu">
						<el-input class="list_inp"
                                  v-model="form.baomingyaoqiu"
                                  placeholder="报名要求"
                                  type="text"
							      :readonly="!isAdd||disabledForm.baomingyaoqiu?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="结束时间" prop="jieshushijian">
						<el-date-picker
							class="list_date"
							v-model="form.jieshushijian"
							format="YYYY-MM-DD HH:mm:ss"
							value-format="YYYY-MM-DD HH:mm:ss"
							type="datetime"
							style="width:100%;"
							:readonly="!isAdd||disabledForm.jieshushijian?true:false"
							placeholder="请选择结束时间" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="评分标准" prop="pingfenbiaozhun">
						<el-input class="list_inp"
                                  v-model="form.pingfenbiaozhun"
                                  placeholder="评分标准"
                                  type="text"
							      :readonly="!isAdd||disabledForm.pingfenbiaozhun?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="竞赛规则" prop="jingsaiguize">
						<el-input v-model="form.jingsaiguize" placeholder="竞赛规则" type="textarea"
						:readonly="!isAdd||disabledForm.jingsaiguize?true:false"
						/>
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="竞赛详情" prop="jingsaixiangqing">
						<editor class="list_editor" :value="form.jingsaixiangqing" placeholder="请输入竞赛详情" :readonly="!isAdd||disabledForm.jingsaixiangqing?true:false"
							@change="(e)=>editorChange(e,'jingsaixiangqing')"></editor>
					</el-form-item>
				</el-col>
			</el-row>
			<div class="formModel_btn_box">
				<el-button class="formModel_cancel" @click="backClick">取消</el-button>
				<el-button class="formModel_confirm"
                           @click="save"
                           type="success"
				>
					保存
				</el-button>
			</div>
		</el-form>
	</div>
</template>
<script setup>
	import {
		ref,
		getCurrentInstance,
		watch,
		onUnmounted,
		onMounted,
		nextTick,
		computed
	} from 'vue';
	import {
		useRoute,
		useRouter
	} from 'vue-router';
    import moment from "moment";
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const route = useRoute()
	const router = useRouter()
	//基础信息
	const tableName = 'jingsaixinxi'
	const formName = '竞赛信息'
	//基础信息
	const breadList = ref([{
		name: formName
	}])
	//获取唯一标识
	const getUUID =()=> {
      return new Date().getTime();
    }
	//form表单
	const form = ref({
		jingsaimingcheng: '',
		jingsaitupian: '',
		jingsaiguize: '',
		jingsaishijian: '',
		jingsaixueke: '',
		jingsaididian: '',
		jingsaixiangqing: '',
		reversetime: '',
		baomingyaoqiu: '',
		jieshushijian: '',
		pingfenbiaozhun: '',
	})
	const formRef = ref(null)
	const id = ref(0)
	const type = ref('')
	const disabledForm = ref({
		jingsaimingcheng : false,
		jingsaitupian : false,
		jingsaiguize : false,
		jingsaishijian : false,
		jingsaixueke : false,
		jingsaididian : false,
		jingsaixiangqing : false,
		reversetime : false,
		baomingyaoqiu : false,
		storeupNumber : false,
		jieshushijian : false,
		pingfenbiaozhun : false,
	})
	const isAdd = ref(false)
	//表单验证
	const rules = ref({
		jingsaimingcheng: [
			{required: true,message: '请输入',trigger: 'blur'}, 
		],
		jingsaitupian: [
		],
		jingsaiguize: [
		],
		jingsaishijian: [
			{required: true,message: '请输入',trigger: 'blur'}, 
		],
		jingsaixueke: [
		],
		jingsaididian: [
		],
		jingsaixiangqing: [
		],
		reversetime: [
		],
		baomingyaoqiu: [
		],
		storeupNumber: [
			{ validator: context.$toolUtil.validator.intNumber, trigger: 'blur' },
		],
		jieshushijian: [
		],
		pingfenbiaozhun: [
		],
	})
	//竞赛图片上传回调
	const jingsaitupianUploadSuccess=(e)=>{
		form.value.jingsaitupian = e
	}
	//methods

	//methods
	//获取info
	const getInfo = ()=>{
		context?.$http({
			url: `${tableName}/info/${id.value}`,
			method: 'get'
		}).then(res => {
			let reg=new RegExp('../../../file','g')
			res.data.data.jingsaixiangqing = res.data.data.jingsaixiangqing.replace(reg,'../../../cl565184106/file');
			form.value = res.data.data
		})
	}
	const crossRow = ref('')
	const crossTable = ref('')
	const crossTips = ref('')
	const crossColumnName = ref('')
	const crossColumnValue = ref('')
	//初始化
	const init = (formId=null,formType='add',formNames='',row=null,table=null,statusColumnName=null,tips=null,statusColumnValue=null) => {
		if(formId){
			id.value = formId
			type.value = formType
		}
		if(formType == 'add'){
			isAdd.value = true
		}else if(formType == 'info'){
			isAdd.value = false
			getInfo()
		}else if(formType == 'edit'){
			isAdd.value = true
			getInfo()
		}
		else if(formType == 'cross'){
			isAdd.value = true
			// getInfo()
			for(let x in row){
				if(x=='jingsaimingcheng'){
					form.value.jingsaimingcheng = row[x];
					disabledForm.value.jingsaimingcheng = true;
					continue;
				}
				if(x=='jingsaitupian'){
					form.value.jingsaitupian = row[x];
					disabledForm.value.jingsaitupian = true;
					continue;
				}
				if(x=='jingsaiguize'){
					form.value.jingsaiguize = row[x];
					disabledForm.value.jingsaiguize = true;
					continue;
				}
				if(x=='jingsaishijian'){
					form.value.jingsaishijian = row[x];
					disabledForm.value.jingsaishijian = true;
					continue;
				}
				if(x=='jingsaixueke'){
					form.value.jingsaixueke = row[x];
					disabledForm.value.jingsaixueke = true;
					continue;
				}
				if(x=='jingsaididian'){
					form.value.jingsaididian = row[x];
					disabledForm.value.jingsaididian = true;
					continue;
				}
				if(x=='jingsaixiangqing'){
					form.value.jingsaixiangqing = row[x];
					disabledForm.value.jingsaixiangqing = true;
					continue;
				}
				if(x=='reversetime'){
					form.value.reversetime = row[x];
					disabledForm.value.reversetime = true;
					continue;
				}
				if(x=='baomingyaoqiu'){
					form.value.baomingyaoqiu = row[x];
					disabledForm.value.baomingyaoqiu = true;
					continue;
				}
				if(x=='storeupNumber'){
					form.value.storeupNumber = row[x];
					disabledForm.value.storeupNumber = true;
					continue;
				}
				if(x=='jieshushijian'){
					form.value.jieshushijian = row[x];
					disabledForm.value.jieshushijian = true;
					continue;
				}
				if(x=='pingfenbiaozhun'){
					form.value.pingfenbiaozhun = row[x];
					disabledForm.value.pingfenbiaozhun = true;
					continue;
				}
			}
			if(row){
				crossRow.value = row
			}
			if(table){
				crossTable.value = table
			}
			if(tips){
				crossTips.value = tips
			}
			if(statusColumnName){
				crossColumnName.value = statusColumnName
			}
			if(statusColumnValue){
				crossColumnValue.value = statusColumnValue
			}
		}
		context?.$http({
			url: `${context?.$toolUtil.storageGet('frontSessionTable')}/session`,
			method: 'get'
		}).then(res => {
			var json = res.data.data
            if (localStorage.getItem('autoSave')) {
                localStorage.removeItem('autoSave')
                save()
            }
		})
	}
	//初始化
	//取消
	const backClick = () => {
		history.back()
	}
	//富文本数据回调
	const editorChange = (e,name) =>{
		form.value[name] = e
	}
	//提交
	const save=()=>{
		if(form.value.jingsaitupian!=null) {
			form.value.jingsaitupian = form.value.jingsaitupian.replace(new RegExp(context?.$config.url,"g"),"");
		}
		var table = crossTable.value
		var objcross = JSON.parse(JSON.stringify(crossRow.value))
		let crossUserId = ''
		let crossRefId = ''
		let crossOptNum = ''
		if(type.value == 'cross'){
			if(crossColumnName.value!=''){
				if(!crossColumnName.value.startsWith('[')){
					for(let o in objcross){
						if(o == crossColumnName.value){
							objcross[o] = crossColumnValue.value
						}
					}
					//修改跨表数据
					changeCrossData(objcross)
				}else{
					crossUserId = context?.$toolUtil.storageGet('userid')
					crossRefId = objcross['id']
					crossOptNum = crossColumnName.value.replace(/\[/,"").replace(/\]/,"")
				}
			}
		}
		formRef.value.validate((valid)=>{
			if(valid){
				if(crossUserId&&crossRefId){
					form.value.crossuserid = crossUserId
					form.value.crossrefid = crossRefId
					let params = {
						page: 1,
						limit: 1000, 
						crossuserid:form.value.crossuserid,
						crossrefid:form.value.crossrefid,
					}
					context?.$http({
						url: `${tableName}/page`,
						method: 'get', 
						params: params 
					}).then(res=>{
						if(res.data.data.total>=crossOptNum){
							context?.$toolUtil.message(`${crossTips.value}`,'error')
							return false
						}else{
							context?.$http({
								url: `${tableName}/${!form.value.id ? "save" : "update"}`,
								method: 'post', 
								data: form.value 
							}).then(res=>{
                                context?.$toolUtil.message(`操作成功`,'success')
                                history.back()
							})
						}
					})
				}else{
					context?.$http({
						url: `${tableName}/${!form.value.id ? "save" : "update"}`,
						method: 'post', 
						data: form.value 
					}).then(res=>{
                        context?.$toolUtil.message(`操作成功`,'success')
                        history.back()
					})
				}
			}
		})
	}
	//修改跨表数据
	const changeCrossData=(row)=>{
        if(type.value == 'cross'){
            context?.$http({
                url: `${crossTable.value}/update`,
                method: 'post',
                data: row
            }).then(res=>{})
        }
	}
	onMounted(()=>{
		type.value = route.query.type?route.query.type:'add'
		let row = null
		let table = null
		let statusColumnName = null
		let tips = null
		let statusColumnValue = null
		if(type.value == 'cross'){
			row = context?.$toolUtil.storageGet('crossObj')?JSON.parse(context?.$toolUtil.storageGet('crossObj')):{}
			table = context?.$toolUtil.storageGet('crossTable')
			statusColumnName = context?.$toolUtil.storageGet('crossStatusColumnName')
			tips = context?.$toolUtil.storageGet('crossTips')
			statusColumnValue = context?.$toolUtil.storageGet('crossStatusColumnValue')
		}
		init(route.query.id?route.query.id:null, type.value,'', row, table, statusColumnName, tips, statusColumnValue)
	})
    onUnmounted(()=>{
        Object.keys(localStorage).map(item=>{
            if(item.startsWith('cross')){
                localStorage.removeItem(item)
            }
        })
    })
</script>
<style lang="scss" scoped>
	// 面包屑盒子
	.bread_view {
		:deep(.breadcrumb) {
			.el-breadcrumb__separator {
			}
			.first_breadcrumb {
				.el-breadcrumb__inner {
				}
			}
			.second_breadcrumb {
				.el-breadcrumb__inner {
				}
			}
		}
	}
	// 表单
	.add_form{
		// form item
		:deep(.el-form-item) {
			//label
			.el-form-item__label {
			}
			// 内容盒子
			.el-form-item__content {
				// 输入框
				.list_inp {

				}
				//日期选择器
				.list_date {
				}
				// 富文本
				.list_editor {
				}
				// 长文本
				.el-textarea__inner {
				}
				//图片上传样式
				.el-upload-list  {
					//提示语
					.el-upload__tip {
					}
					//外部盒子
					.el-upload--picture-card {
						//图标
						.el-icon{
						}
					}
					.el-upload-list__item {
					}
				}
			}
		}
	}
	// 按钮盒子
	.formModel_btn_box {
		.formModel_cancel {
		}
		.formModel_cancel:hover {
		}
		
		.formModel_confirm {
		}
		.formModel_confirm:hover {
		}
	}
</style>
<style lang="scss">
.edit_view {
    width: 1200px;
    margin: 20px auto;
    padding: 0px ;
    background: #fff;
    overflow: hidden;
    font-size: 16px;
    color:#666;
}
.edit_view .add_form{
    width: 100%;
    padding: 30px;
    border:0px solid #eee
}
.edit_view .add_form .el-form-item{
    margin: 0px 0px 20px;
    display: flex;
}
.edit_view .add_form .el-form-item .el-form-item__label{
    width: 150px;
    background: none;
    text-align: right;
    display: block;
    font-size: 16px;
    color: rgb(51, 51, 51);
    font-weight: 500;
}
.edit_view .add_form .el-form-item .el-form-item__content{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-wrap: wrap;
    width: calc(100% - 120px);
}
.edit_view .add_form .el-form-item .el-form-item__content .list_inp{
    height: 36px;
    line-height: 36px;
    border: 1px solid rgb(221, 221, 221);
    padding: 0px 10px;
    width: 100%;
    box-sizing: border-box;
    background: rgb(255, 255, 255);
    font-size: 16px;
}


.edit_view .add_form .el-form-item .el-form-item__content .list_date{
    line-height: 36px;
    border: 1px solid rgb(221, 221, 221);
    box-sizing: border-box;
    width: 100%;
    border-radius: 0px;
    background: rgb(255, 255, 255);
    font-size: 16px;
}




.edit_view .add_form .el-form-item .el-form-item__content .el-textarea{
}
.edit_view .add_form .el-form-item .el-form-item__content .el-textarea .el-textarea__inner{
    width: 100%;
    min-height: 150px;
    padding: 12px;
    border: 1px solid rgb(221, 221, 221);
    border-radius: 0px;
    color: #666;
    font-size: 16px;
}


.edit_view .add_form .el-form-item .el-form-item__content .el-upload--picture-card{
    background-color: rgb(255, 255, 255);
    width: 100px;
    height: 90px;
    line-height: 100px;
    text-align: center;
    border: 1px solid rgb(221, 221, 221);
    border-radius: 0px;
    cursor: pointer;
}

.edit_view .add_form .el-form-item .el-form-item__content .el-upload--picture-card .el-icon{
    font-size: 32px;
    color: #999;
}

.edit_view .add_form .el-form-item .el-form-item__content .img-uploader .el-upload__tip{
    font-size: 15px;
    color: #666;
    margin: 0;
}


.edit_view .add_form .el-form-item .el-form-item__content .list_editor{
    width: 100%;
    height: auto;
    margin: 0px;
    padding: 0px;
    border-radius: 0px;
    background: rgb(255, 255, 255);
    border: 1px solid rgb(221, 221, 221);
    min-height: 300px;
}

</style>
<template>
	<div>
		<div class="register_view">
			<el-form :model="registerForm" class="register_form">
				<div class="title_view">
                    {{projectName}}注册
                </div>
				<div class="list_item">
					<div class="list_label">评委账号：</div>
					<el-input class="list_inp"
						 v-model="registerForm.pingweizhanghao" 
						 placeholder="请输入评委账号"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">评委密码：</div>
					<el-input class="list_inp"
						 v-model="registerForm.pingweimima" 
						 placeholder="请输入评委密码"
						 type="password"
						 />
				</div>
				<div class="list_item">
					<div class="list_label">确认评委密码：</div>
					<el-input class="list_inp" v-model="registerForm.pingweimima2" type="password" placeholder="请输入确认评委密码" />
				</div>
				<div class="list_item">
					<div class="list_label">评委姓名：</div>
					<el-input class="list_inp"
						 v-model="registerForm.pingweixingming" 
						 placeholder="请输入评委姓名"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">头像：</div>
					<div :style='{}' class="list_file_list">
						<uploads
							action="file/upload" 
							tip="请上传头像"
							:fileUrls="registerForm.touxiang?registerForm.touxiang:''" 
							@change="touxiangUploadSuccess">
						</uploads>
					</div>
				</div>
				<div class="list_item">
					<div class="list_label">性别：</div>
					<el-select 
						class="list_sel"
						v-model="registerForm.xingbie" 
						placeholder="请选择性别"
						>
						<el-option v-for="item in pingweixingbieLists" :label="item" :value="item"></el-option>
					</el-select>
				</div>

				<div class="list_item">
					<div class="list_label">联系电话：</div>
					<el-input class="list_inp"
						 v-model="registerForm.lianxidianhua" 
						 placeholder="请输入联系电话"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">专业领域：</div>
					<el-input class="list_inp"
						 v-model="registerForm.zhuanyelingyu" 
						 placeholder="请输入专业领域"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">工作单位：</div>
					<el-input class="list_inp"
						 v-model="registerForm.gongzuodanwei" 
						 placeholder="请输入工作单位"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">证书：</div>
					<div :style='{}' class="list_file_list">
						<uploads
							action="file/upload" 
							tip="请上传证书"
							:fileUrls="registerForm.zhengshu?registerForm.zhengshu:''" 
							@change="zhengshuUploadSuccess">
						</uploads>
					</div>
				</div>
				<div class="list_btn">
					<el-button class="register" type="success" @click="handleRegister">注册</el-button>
					<div class="r-login" @click="close">已有账号，直接登录</div>
				</div>
			</el-form>
		</div>
	</div>
</template>
<script setup>
	import {
		ref,
		getCurrentInstance,
		nextTick,
		onMounted,
	} from 'vue';
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const projectName = context?.$project.projectName
	//获取注册类型
	import { useRoute } from 'vue-router';
	const route = useRoute()
	const tableName = ref('pingwei')
	
	//公共方法
	const getUUID=()=> {
		return new Date().getTime();
	}
	const registerForm = ref({
        xingbie: '',
	})
	const pingweixingbieLists = ref([])
	const init=()=>{
		pingweixingbieLists.value = "男,女".split(',')
	}
    const touxiangUploadSuccess=(fileUrls)=> {
        registerForm.value.touxiang = fileUrls;
    }
    const zhengshuUploadSuccess=(fileUrls)=> {
        registerForm.value.zhengshu = fileUrls;
    }

	//注册按钮
	const handleRegister = () => {
		let url = tableName.value +"/register";
		if((!registerForm.value.pingweizhanghao)){
			context?.$toolUtil.message(`评委账号不能为空`,'error')
			return false
		}
		if((!registerForm.value.pingweimima)){
			context?.$toolUtil.message(`评委密码不能为空`,'error')
			return false
		}
		if(registerForm.value.pingweimima!=registerForm.value.pingweimima2){
			context?.$toolUtil.message('两次密码输入不一致','error')
			return false
		}
		if((!registerForm.value.pingweixingming)){
			context?.$toolUtil.message(`评委姓名不能为空`,'error')
			return false
		}
		if(registerForm.value.touxiang!=null){
			registerForm.value.touxiang = registerForm.value.touxiang.replace(new RegExp(context?.$config.url,"g"),"");
		}
		if(registerForm.value.zhengshu!=null){
			registerForm.value.zhengshu = registerForm.value.zhengshu.replace(new RegExp(context?.$config.url,"g"),"");
		}
		context?.$http({
			url:url,
			method:'post',
			data:registerForm.value
		}).then(res=>{
			context?.$toolUtil.message('注册成功','success', obj=>{
				context?.$router.push({
					path: "/login"
				});
			})
		})
	}
	//返回登录
	const close = () => {
		context?.$router.push({
			path: "/login"
		});
	}
	init()
	onMounted(()=>{

	})
</script>
<style lang="scss" scoped>
	
	.register_view {
        background-image: url("")!important;
		// 表单盒子
		.register_form {
		}
		// 标题样式
		.title_view {
		}
		// item盒子
		.list_item {
			// label
			.list_label {
			}
			// 输入框
			:deep(.list_inp) {
			}
		}
		//下拉框样式
		:deep(.list_sel) {
			//去掉默认样式
			.select-trigger{
				height: 100%;
				.el-input{
					height: 100%;
				}
			}
		}
		//按钮盒子
		.list_btn {
			//注册按钮
			.register {
			}
			//注册按钮悬浮样式
			.register:hover {
			}
			//已有账号
			.r-login {
			}
		}
		//图片上传样式
		.list_file_list  {
			//提示语
			:deep(.el-upload__tip){
			}
			//外部盒子
			:deep(.el-upload--picture-card){
				//图标
				.el-icon{
				}
			}
			:deep(.el-upload-list__item) {
			}
		}
	}
</style>
<style>
.register_view {
    min-height: 100vh;
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background:#eaeaea;
}


.register_form{  width:1200px; margin:20px auto; padding:30px 80px 40px 720px; background:url(http://clfile.zggen.cn/20240916/e7210ebe3fed4296a4ff5a4b1d77da3f.jpg) no-repeat left bottom / 640px auto,#fff; font-size:16px; border-radius:0px; transform:scale(1); -webkit-transform:scale(1); -ms-transform:scale(1); z-index:5; box-shadow:0px -1px 4px 0px rgba(0,0,0,0.05); }

.register_form:before { content: ""; width: 100%; height: 0px; border-radius: 10px;  position: absolute;  top: -10px; background: rgba(255, 255, 255, .6);  left: 0; transform: scale(.95); -webkit-transform: scale(.95);  -ms-transform: scale(.95);  z-index: -1; }


.register_form .title_view{  width:calc(100% + 0px); float:left; line-height:46px; font-size:22px; font-weight:600; letter-spacing:0.5px; background:none;  color:#333; position:relative; margin-bottom:20px; margin-left:0px; padding-left:0px; text-align:center; }
.register_form .title_view:before { content: "";  width: 0px; height: 100%;  position: absolute;  top: 0; left: -50px; background: #8b5c7e; }


.register_form .list_item {  width: 100%; padding:0 10px; display: flex; align-items: center;   justify-content: flex-start;  margin: 0 0 20px; border:1px solid #eee;  border-radius:30px; }
.register_form .list_item .list_label{ display:block; margin-right:10px; white-space:nowrap; font-size:16px;  }
.register_form .list_item .list_label i {  font-size:24px; color:#999;  }
.register_form .list_item .el-input .el-input__inner{ width:100%; border:none; border-bottom:0px solid #ddd; height:40px; line-height:40px; border-radius:0; font-size:16px; color:#999;   }
.register_form .list_item .el-select { width:100%; }
.register_form .list_type{ margin-bottom:20px;  }
.register_form .list_code{  width: 100%; padding:0 0 0 10px; display: flex; align-items: center;   justify-content: flex-start;  margin: 0 0 20px;  border:1px solid #eee;  border-radius:30px;  }
.register_form .list_code .el-input .el-input__inner{ width:100%; border:none; border-bottom:0px solid #ddd; height:40px; line-height:40px; border-radius:0; font-size:16px; color:#999;   }


.register_form .list_item .list_file_list{ width: 100%;  margin:10px 20px 10px 0px; flex:1; }

.register_form .list_item .list_file_list .el-upload{ background-color: rgb(255, 255, 255);  width: 100px;  height: 60px; line-height: 68px;  text-align: center;  border: 1px solid #eee;  border-radius: 0px; cursor: pointer; }

.register_form .list_item .list_file_list .el-upload .el-icon{ font-size: 26px; color: rgb(187, 187, 187); }

.register_form .list_item .list_file_list .img-uploader .el-upload__tip{ font-size: 16px;  color: rgb(102, 102, 102);margin: 7px 0px 0px; display: flex; align-items: center;  justify-content: flex-start; }


.register_form .list_item .el-upload-dragger{ background-color: rgb(255, 255, 255); border: 0px solid rgb(221, 221, 221);  border-radius: 30px;  box-sizing: border-box;  width: 100%; height: auto; text-align: center; cursor: pointer; overflow: hidden; padding: 4px 20px 10px;  margin:10px 20px 10px 0px; }

.register_form .list_item .el-upload-dragger .el-icon--upload{ font-size: 48px; color: var(--theme); line-height: 40px;  margin: 0px; }

.register_form .list_item .upload-demo .el-upload__tip{ font-size: 16px; color: rgb(102, 102, 102); margin: 7px 0px 10px; }

.register_form .list_item .el-upload-dragger .el-upload__text{  font-size: 16px;   }
.register_form .list_item .el-upload-dragger .el-upload__text em{ color: var(--theme); }


.register_form .list_item .list_radio{ display: flex; width: 80%; align-items: center; flex-wrap: wrap; background: none; height: 40px; flex: 1; }

.register_form .list_item .list_radio .el-radio{ width: auto; margin: 0px 20px 0px 0px; display: flex; justify-content: center; align-items: center; }

.register_form .list_item .list_radio .el-radio .el-radio__label { font-size: 16px; color: rgb(153, 153, 153);   }

.register_form .list_item .list_radio .el-radio.is-checked .el-radio__label { color:var(--theme);   }

.register_form .list_item .list_radio .el-radio .el-radio__input .el-radio__inner{ border-color: rgb(153, 153, 153); background: rgb(255, 255, 255); }

.register_form .list_item .list_radio .el-radio .el-radio__input.is-checked .el-radio__inner{ border-color: var(--theme); background: var(--theme);  }


.register_form .list_item .list_checkbox { display: flex; width: 80%;  flex-wrap: wrap; align-items: center; background: none; height: 40px; flex:1; }

.register_form .list_item .list_checkbox .el-checkbox{ width: auto; margin: 0px 20px 0px 0px; display: flex;  justify-content: center;  align-items: center; }

.register_form .list_item .list_checkbox .el-checkbox .el-checkbox__label { color: rgb(153, 153, 153);  font-size: 16px; }

.register_form .list_item .list_checkbox .el-checkbox.is-checked .el-checkbox__label { color:var(--theme); }

.register_form .list_item .list_checkbox .el-checkbox .el-checkbox__input .el-checkbox__inner{ border-color: rgb(153, 153, 153);  background: rgb(255, 255, 255); }

.register_form .list_item .list_checkbox .el-checkbox.is-checked .el-checkbox__input .el-checkbox__inner{ border-color: var(--theme); background: var(--theme); }


.register_form .list_code{ display: flex; align-items: center; width: 100%; margin: 10px auto; }
.register_form .list_code .list_code_label{ font-size:16px; }

.register_form .list_code .list_code_item{ width: calc(100% - 130px); display: flex; align-items: center; flex: 1;  }

.register_form .list_code .list_code_item .list_code_inp{  font-size:16px; color:#999; flex: 1;  }

.register_form .list_code .list_code_item .list_code_btn{ width: 120px; height: 40px;  line-height: 40px; padding: 0px;  border: 0px solid rgb(73, 189, 227); background:var(--theme); border-radius: 0 30px 30px 0; color: rgb(255, 255, 255); font-size: 15px; }


.register_form .list_btn{  margin-top:20px; text-align:center; display: flex; flex-wrap:wrap;  }
.register_form .list_btn .register{ width: 100%; height: 46px; line-height: 46px; background: var(--theme); border: 0px solid #ccc; font-weight: 600; font-size: 18px; color: #fff; margin-bottom:0px; padding:0; border-radius:30px;  } 
.register_form .list_btn .register:hover { } 
.register_form .list_btn .r-login{ width: 100%;  order:-1;  font-size: 16px; color: #333; background: #eee; height: 46px; line-height: 46px; border-radius:30px; margin-bottom:20px; } 
.register_form .list_btn .r-login:hover{ cursor:pointer; color: #1043a9;  } 
.register_form .el-select,.el-input {
  border: none;
}

</style>
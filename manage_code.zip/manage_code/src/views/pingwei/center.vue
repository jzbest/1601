<template>
	<div>
		<div class="center_view edit_form">
			<el-form class="userinfo_form" ref="userinfoFormRef" :model="form">
				<el-row>
					<el-col :span="12">
						<el-form-item label="评委账号" prop="pingweizhanghao">
							<el-input class="list_inp" v-model="user.pingweizhanghao" readonly placeholder="评委账号" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="评委姓名" prop="pingweixingming">
							<el-input class="list_inp" v-model="user.pingweixingming"  placeholder="评委姓名" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="头像" prop="touxiang">
							<uploads
								action="file/upload" 
								tip="请上传头像"
								style="width: 100%;text-align: left;"
								:fileUrls="user.touxiang?user.touxiang:''" 
								@change="pingweitouxiangUploadSuccess">
							</uploads>
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="性别" prop="xingbie">
							<el-select 
								class="list_sel" 
								v-model="user.xingbie" 
								placeholder="请选择性别"
								>
								<el-option v-for="item in pingweixingbieLists" :label="item" :value="item"></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="联系电话" prop="lianxidianhua">
							<el-input class="list_inp" v-model="user.lianxidianhua"  placeholder="联系电话" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="专业领域" prop="zhuanyelingyu">
							<el-input class="list_inp" v-model="user.zhuanyelingyu"  placeholder="专业领域" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="工作单位" prop="gongzuodanwei">
							<el-input class="list_inp" v-model="user.gongzuodanwei"  placeholder="工作单位" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="证书" prop="zhengshu">
							<uploads
								action="file/upload" 
								tip="请上传证书"
								style="width: 100%;text-align: left;"
								:fileUrls="user.zhengshu?user.zhengshu:''" 
								@change="pingweizhengshuUploadSuccess">
							</uploads>
						</el-form-item>
					</el-col>
					<span class="formModel_btn_box">
						<el-button class='confirm_btn' type="primary" @click="onSubmit">保存</el-button>
					</span>
				</el-row>
			</el-form>
		</div>
	</div>
</template>

<script setup>
	import { isNumber,isIntNumer,isEmail,isMobile,isPhone,isURL,checkIdCard } from "@/utils/toolUtil";
	import {
		reactive,
		ref,
		getCurrentInstance
	} from 'vue'
	import { useStore } from 'vuex'
	const store = useStore()
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const tableName = ref('pingwei')
	const user = ref({})
	const pingweixingbieLists = ref([])
	const init = () => {
		pingweixingbieLists.value = "男,女".split(',')
	}
	const pingweitouxiangUploadSuccess=(fileUrls)=> {
	    user.value.touxiang = fileUrls;
	}
	const pingweizhengshuUploadSuccess=(fileUrls)=> {
	    user.value.zhengshu = fileUrls;
	}
	const onSubmit = () => {
		if((!user.value.pingweizhanghao)){
			context?.$toolUtil.message(`评委账号不能为空`,'error')
			return false
		}
		if((!user.value.pingweimima)){
			context?.$toolUtil.message(`评委密码不能为空`,'error')
			return false
		}
		if((!user.value.pingweixingming)){
			context?.$toolUtil.message(`评委姓名不能为空`,'error')
			return false
		}
		if(user.value.touxiang!=null){
			user.value.touxiang = user.value.touxiang.replace(new RegExp(context?.$config.url,"g"),"");
		}
		if(user.value.zhengshu!=null){
			user.value.zhengshu = user.value.zhengshu.replace(new RegExp(context?.$config.url,"g"),"");
		}
		store.dispatch('user/update',user.value).then(res=>{
			if(res?.data&&res.data.code==0)context?.$toolUtil.message('修改成功','success')
		})

	}
	const getInfo = () => {
		context?.$http({
			url: `${tableName.value}/session`,
			method: 'get'
		}).then(res => {
			user.value = res.data.data
			init()
		})
	}
	getInfo()
</script>

<style lang="scss" scoped>
	// 表单
	.userinfo_form {
		// form item
		:deep(.el-form-item) {
			// 内容盒子
			.el-form-item__content{
			}
			// 输入框
			.list_inp {
			}
			//下拉框样式
			.list_sel {
				//去掉默认样式
				.select-trigger{
					height: 100%;
					.el-input{
						height: 100%;
					}
				}
			}
			//图片上传样式
			.el-upload-list  {
				//提示语
				.el-upload__tip {
				}
				//外部盒子
				.el-upload--picture-card {
					//图标
					.el-icon{
					}
				}
				.el-upload-list__item {
				}
			}

		}
		// 按钮盒子
		.formModel_btn_box {
			// 确定按钮
			.confirm_btn {
			}
			// 确定按钮-悬浮
			.confirm_btn:hover {
			}
		}
	}
</style>

	import {
		createRouter,
		createWebHashHistory
	} from 'vue-router'
	import news from '@/views/news/list'
	import jingsaixinxi from '@/views/jingsaixinxi/list'
	import xuesheng from '@/views/xuesheng/list'
	import syslog from '@/views/syslog/list'
	import pingwei from '@/views/pingwei/list'
    import menu_manage from '@/views/menu_manage/list'
	import storeup from '@/views/storeup/list'
	import users from '@/views/users/list'
	import dafenxinxi from '@/views/dafenxinxi/list'
	import jiarutuandui from '@/views/jiarutuandui/list'
	import baomingxinxi from '@/views/baomingxinxi/list'
	import jiangpinxinxi from '@/views/jiangpinxinxi/list'
	import config from '@/views/config/list'
	import usersCenter from '@/views/users/center'
	import pingweiRegister from '@/views/pingwei/register'
	import pingweiCenter from '@/views/pingwei/center'

export const routes = [{
		path: '/login',
		name: 'login',
        meta: { title: '登录' },
		component: () => import('../views/login.vue')
	},{
		path: '/',
		name: '首页',
        meta: { title: '首页' },
		component: () => import('../views/index'),
		children: [{
			path: '/',
			name: '首页',
			component: () => import('../views/HomeView.vue'),
			meta: {
				affix: true,
                title: '首页'
			}
		}, {
			path: '/updatepassword',
			name: 'updatepassword',
            meta: { title: '修改密码' },
			component: () => import('../views/updatepassword.vue')
		}

		,{
			path: '/usersCenter',
			name: 'usersCenter',
            meta: { title: '管理员个人中心' },
			component: usersCenter
		}
		,{
			path: '/pingweiCenter',
			name: 'pingweiCenter',
            meta: { title: '评委个人中心' },
			component: pingweiCenter
		}
		,{
			path: '/news',
			name: 'news',
            meta: { title: '系统通知' },
			component: news
		}
		,{
			path: '/jingsaixinxi',
			name: 'jingsaixinxi',
            meta: { title: '竞赛信息' },
			component: jingsaixinxi
		}
		,{
			path: '/xuesheng',
			name: 'xuesheng',
            meta: { title: '学生' },
			component: xuesheng
		}
		,{
			path: '/syslog',
			name: 'syslog',
            meta: { title: '操作日志' },
			component: syslog
		}
		,{
			path: '/pingwei',
			name: 'pingwei',
            meta: { title: '评委' },
			component: pingwei
		}
        ,{
            path: '/menu',
            name: 'menu',
            meta: { title: '菜单权限管理' },
            component: menu_manage
        }
		,{
			path: '/storeup',
			name: 'storeup',
            meta: { title: '我的收藏' },
			component: storeup
		}
		,{
			path: '/users',
			name: 'users',
            meta: { title: '管理员' },
			component: users
		}
		,{
			path: '/dafenxinxi',
			name: 'dafenxinxi',
            meta: { title: '打分信息' },
			component: dafenxinxi
		}
		,{
			path: '/jiarutuandui',
			name: 'jiarutuandui',
            meta: { title: '加入团队' },
			component: jiarutuandui
		}
		,{
			path: '/baomingxinxi',
			name: 'baomingxinxi',
            meta: { title: '报名信息' },
			component: baomingxinxi
		}
		,{
			path: '/jiangpinxinxi',
			name: 'jiangpinxinxi',
            meta: { title: '奖品信息' },
			component: jiangpinxinxi
		}
		,{
			path: '/config',
			name: 'config',
            meta: { title: '轮播图' },
			component: config
		}
		]
	},
	{
		path: '/pingweiRegister',
		name: 'pingweiRegister',
        meta: { title: '评委注册' },
		component: pingweiRegister
	},
]

const router = createRouter({
	history: createWebHashHistory(process.env.BASE_URL),
	routes
})

export default router
